### Dwarves Sprites Sources

<table style="border: 0px;">
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Static Preview](preview.png)
    </td>
  </tr>
  <tr style="border: 0px;">
    <td style="border: 0px; vertical-align: top; text-align: center;">
      ![Animated Preview](preview.gif)
    </td>
  </tr>
</table>


[OpenGameArt.org submission](https://opengameart.org/node/83728)

#### Source Assets:
---

By [diamonddmgirl](https://opengameart.org/users/diamonddmgirl):
- [24x32 Black Character Pack](https://opengameart.org/node/72198) (OGA BY 3.0)

By [GrumpyDiamond](https://opengameart.org/users/grumpydiamond):
- [Pixel Weapons1](https://opengameart.org/node/54590) (CC0)

By [Svetlana Kushnariova (Cabbit)](https://opengameart.org/users/cabbit):
- [24x32 bases](https://opengameart.org/node/24944) (CC0)
- [24x32 characters, 16x16 tiles](https://opengameart.org/node/72969) (OGA BY 3.0 / CC BY 3.0)
